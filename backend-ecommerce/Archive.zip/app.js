import express from "express"
import cors from 'cors'
import { corsOrigon } from './constants/constants.js'
import cookieParser from "cookie-parser"


const app = express()


app.use(cors(
    {
        origin: corsOrigon
    }
))
app.use(express.json({ limit: '16kb' }))
app.use(express.urlencoded({ extended: true, limit: '16kb' }))
app.use(express.static('public'))
app.use(cookieParser())
app.use("/public/images", express.static("public/images"))

//Import Routes




export default app