export const PORT = 3000
export const corsOrigon = "*"
